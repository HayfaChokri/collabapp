#!/bin/bash

# Stop and remove all containers except MongoDB
docker-compose down --remove-orphans

# Remove all images under the Compose project "h_chokripfe" except MongoDB
docker rmi $(docker images -q --filter "label=com.docker.compose.project=h_chokripfe" | grep -v $(docker images -q --filter "reference=mongodb*"))

# Rebuild and run the services
docker-compose up -d --build