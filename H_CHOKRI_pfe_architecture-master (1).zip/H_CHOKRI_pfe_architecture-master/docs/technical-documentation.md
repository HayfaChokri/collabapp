# University Socio-Economic Collaboration Platform

## Technical Documentation & MVP Specification

### Table of Contents
1. [Project Overview](#project-overview)
2. [Architecture](#architecture)
3. [Technology Stack](#technology-stack)
4. [Microservices Structure](#microservices-structure)
5. [User Roles & Permissions](#user-roles--permissions)
6. [Service Provider Types & Categories](#service-provider-types--categories)
7. [Database Schema](#database-schema)
8. [API Endpoints](#api-endpoints)
9. [Frontend Routes](#frontend-routes)
10. [File Management](#file-management)
11. [Internationalization](#internationalization)
12. [Development Progress](#development-progress)
13. [Deployment](#deployment)
14. [Future Enhancements](#future-enhancements)

## Project Overview

The University Socio-Economic Collaboration Platform is designed to facilitate connections between university students and various service providers including industrial enterprises, associations, training structures, incubators, and advertising partners. The platform enables service providers to post opportunities while allowing students to apply for these services and communicate with providers.

## Architecture

The application follows a microservices architecture with the following components:

- **Frontend**: React.js single-page application
- **Backend**: Multiple Node.js microservices
- **Database**: MongoDB
- **API Gateway**: Central entry point for all client requests
- **Authentication**: JWT-based with Google OAuth support
- **Real-time Communication**: WebSockets for chat and notifications
- **File Storage**: MongoDB GridFS

## Technology Stack

### Frontend
- React.js (with Router v6+)
- TypeScript
- State management: Context API / Redux
- React Query / Axios for API calls
- react-i18next for internationalization
- React Bootstrap & custom components
- Font Awesome icons
- Advanced UI libraries:
  - CKEditor for rich text editing
  - FullCalendar for calendar views
  - ApexCharts for data visualization
  - React Dropzone for file uploads
  - React Table for data tables

### Backend
- Node.js with Express.js
- Microservices architecture
- JWT-based authentication and authorization
- Google OAuth2 for Gmail-based login
- i18next for backend internationalization
- File uploads via Multer and GridFS

### Database
- MongoDB v8.0.3

### Communication
- Socket.io for real-time chat and notifications

### Deployment
- Docker and Docker Compose
- One container per microservice

## Microservices Structure

### Gateway Service
- Central entry point for all client requests
- Request routing to appropriate microservices
- Response aggregation
- Rate limiting and basic security

### Auth Service
- User registration and authentication
- JWT token generation and validation
- Google OAuth integration
- Password management

### Admin Service
- User management (create university employees)
- Role assignment
- Service category management
- Liquibase data seeding (Super Admin + Service Categories)

### Student Service
- Student profile management
- Service application handling
- Document upload for applications
- Application status tracking

### Provider Services (5 separate microservices)
1. **Entreprise Industrielle Service**
   - Manages industrial enterprise providers
   - Handles internships, job offers, and research opportunities

2. **Association Service**
   - Manages association providers
   - Handles various activities, club animations, and training sessions

3. **Structure de Formation Service**
   - Manages training structure providers
   - Handles training offers

4. **Incubateur Service**
   - Manages incubator providers
   - Handles incubation offers, awareness days, and calls for applications

5. **Partenaire Publicitaire Service**
   - Manages advertising partner providers
   - Handles commercial offers and advertising displays

### Chat Service
- WebSocket communication
- Student ↔ Provider messaging
- Message history management

### Notification Service
- Real-time alerts
- Application status notifications
- Message notifications
- General announcements

### File Service
- File upload with Multer + GridFS
- Download, delete, and retrieve files
- File metadata management
- Access control for authenticated users

### Audit Service
- System activity logging
- User action tracking
- Security event monitoring

### Logging Service
- Application logs management
- Error tracking
- Performance monitoring

## User Roles & Permissions

### Roles
1. **SUPER_ADMIN**
2. **UNIVERSITY_EMPLOYEE**
3. **STUDENT**
4. **ENTREPRISE_INDUSTRIELLE**
5. **ASSOCIATION**
6. **STRUCTURE_DE_FORMATION**
7. **INCUBATEUR**
8. **PARTENAIRE_PUBLICITAIRE**

### Permissions Matrix

| Role | Create | Read | Update | Delete | Manage Users | Chat | Notifications |
|------|--------|------|--------|--------|--------------|------|---------------|
| SUPER_ADMIN | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ |
| UNIVERSITY_EMPLOYEE | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ |
| SERVICE PROVIDERS (5) | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ |
| STUDENT | ✅(apply) | ✅ | ❌ | ❌ | ❌ | ✅ | ✅ |

## Service Provider Types & Categories

When a provider signs up, selecting one of these 5 roles automatically assigns them the following service categories:

| Role | Assigned Service Categories |
|------|----------------------------|
| ENTREPRISE_INDUSTRIELLE | Offres de stages et PFE, Offres d'emploi, Offres de recherche |
| ASSOCIATION | Activités diverses, Animation des clubs, Sessions de formations |
| STRUCTURE_DE_FORMATION | Offres de formations |
| INCUBATEUR | Offres d'incubation, Journées de sensibilisation, Appels à candidatures |
| PARTENAIRE_PUBLICITAIRE | Offres commerciales, Affichage des publicités |

## API Endpoints
### Auth Service
- POST /api/auth/register - Register a new user
- POST /api/auth/login - Login with email/password
- GET /api/auth/google - Initiate Google OAuth login
- GET /api/auth/google/callback - Google OAuth callback
- POST /api/auth/refresh-token - Refresh JWT token
- POST /api/auth/logout - Logout user
### Admin Service
- POST /api/admin/users - Create a new university employee
- GET /api/admin/users - Get all users
- PUT /api/admin/users/:id - Update user
- DELETE /api/admin/users/:id - Delete user
- GET /api/admin/categories - Get all service categories
- POST /api/admin/categories - Create a new service category
- PUT /api/admin/categories/:id - Update service category
- DELETE /api/admin/categories/:id - Delete service category
### Student Service
- POST /api/students/applications - Apply to a service
- GET /api/students/applications - Get student's applications
- GET /api/students/applications/:id - Get application details
- POST /api/students/documents - Upload documents
### Provider Services (common endpoints)
- POST /api/providers/services - Create a new service
- GET /api/providers/services - Get provider's services
- GET /api/providers/services/:id - Get service details
- PUT /api/providers/services/:id - Update service
- DELETE /api/providers/services/:id - Delete service
- GET /api/providers/applications - Get applications for provider's services
- PUT /api/providers/applications/:id - Update application status
### Chat Service
- GET /api/chats - Get user's chats
- GET /api/chats/:id - Get chat details
- POST /api/chats/:id/messages - Send a message
- WebSocket events for real-time messaging
### Notification Service
- GET /api/notifications - Get user's notifications
- PUT /api/notifications/:id - Mark notification as read
- DELETE /api/notifications/:id - Delete notification
- WebSocket events for real-time notifications
### File Service
- POST /api/files - Upload a file
- GET /api/files/:id - Download a file
- DELETE /api/files/:id - Delete a file
- GET /api/files/metadata/:id - Get file metadata
## Frontend Routes
- /login - Login page
- /signup/student - Student registration (includes Student ID)
- /signup/provider - Provider registration (selects one of 5 provider roles)
- /dashboard - Dashboard (auto-routes by role)
- /services/:categoryId - Services by category
- /services/:id/view - View service details
- /services/:id/apply - Apply to a service
- /services/:id/edit - Edit service
- /files/:id/view - View file
- /notifications - User notifications
- /chat - Chat interface
## File Management
The file-service handles all file operations using MongoDB GridFS:

- Upload files using POST /api/files
- Download files using GET /api/files/:id
- Delete files using DELETE /api/files/:id
- Retrieve file metadata using GET /api/files/metadata/:id
## Internationalization
### Frontend
- Uses react-i18next
- Supports French and English
- Translation files stored in public/locales/{lang}/translation.json
### Backend
- Uses i18next with middleware
- Loads translation files per request based on headers or tokens
## Development Progress
### Completed
- Basic project structure and architecture
- Docker configuration for all microservices
- Database schema design
- Authentication service implementation
- File service implementation
- Basic frontend structure with routing
### In Progress
- Student service implementation
- Provider services implementation
- Admin service implementation
- Frontend UI components development
- Integration of authentication with frontend
### Pending
- Chat service implementation
- Notification service implementation
- Advanced UI features
- Testing and quality assurance
- Performance optimization
## Deployment
The application is deployed using Docker Compose with the following services:

- MongoDB database
- Gateway service
- Auth service
- Admin service
- Student service
- 5 Provider services (one for each provider type)
- Chat service
- Notification service
- File service
- Audit service
- Logging service
- Frontend application
## Future Enhancements
1. Mobile Application
   
   - Develop native mobile apps for iOS and Android
2. Analytics Dashboard
   
   - Implement advanced analytics for administrators
   - Track platform usage and engagement metrics
3. Advanced Search
   
   - Implement full-text search capabilities
   - Add filters and sorting options
4. Recommendation System
   
   - Suggest relevant services to students based on their profile and history
5. Integration with University Systems
   
   - Connect with existing university information systems
   - Automate student verification
6. Multi-language Support
   
   - Expand language options beyond French and English
7. Accessibility Improvements
   
   - Ensure compliance with accessibility standards
   - Support screen readers and keyboard navigation
8. Performance Optimization
   
   - Implement caching strategies
   - Optimize database queries
   - Add load balancing for high traffic

## Database Schema

### Users Collection
```json
{
  "_id": "ObjectId",
  "email": "String",
  "passwordHash": "String",
  "googleId": "String",
  "role": "String", // from roles list
  "studentId": "String", // for students
  "providerType": "String", // for service providers
  "serviceCategories": ["ObjectId"]
}
```
### Service Categories Collection
```json
{
  "_id": "ObjectId",
  "name": "String", 
  "description": "String",
  "assignedToRole": "String", 
  "isActive": "Boolean",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Services Collection
```json
{
  "_id": "ObjectId",
  "uuid": "String",
  "title": "String",
  "description": "String",
  "categoryId": "ObjectId", 
  "postedBy": "ObjectId", 
  "companyId": "ObjectId", 
  "type": "String",
  "requirements": ["String"],
  "duration": {
    "years": "Number",
    "months": "Number"
  },
  "location": "String",
  "deadline": "Date",
  "attachments": ["String"],
  "isActive": "Boolean",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Applications Collection
```json
{
  "_id": "ObjectId",
  "uuid": "String",
  "studentId": "ObjectId",
  "serviceId": "ObjectId",
  "offerId": "ObjectId",
  "status": "String", 
  "notes": "String",
  "documents": [
    {
      "type": "String",
      "url": "String",
      "uploadedAt": "Date"
    }
  ],
  "feedback": "String",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```
### Companies Collection
```json
{
  "_id": "ObjectId",
  "uuid": "String",
  "name": "String",
  "description": "String",
  "industry": "String",
  "size": "Number",
  "location": "String",
  "website": "String",
  "logo": "String",
  "contactEmail": "String",
  "phone": "String",
  "ownerId": "ObjectId",
  "isActive": "Boolean",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```
### Offers Collection
```json
{
  "_id": "ObjectId",
  "uuid": "String",
  "title": "String",
  "description": "String",
  "type": "String",
  "companyId": "ObjectId",
  "requirements": ["String"],
  "duration": {
    "years": "Number",
    "months": "Number"
  },
  "location": "String",
  "deadline": "Date",
  "attachedDocs": ["String"],
  "postedBy": "ObjectId",
  "isActive": "Boolean",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```
### Interviews Collection
```json
{
  "_id": "ObjectId",
  "uuid": "String",
  "applicationId": "ObjectId",
  "studentId": "ObjectId",
  "providerId": "ObjectId",
  "offerId": "ObjectId",
  "scheduledDate": "Date",
  "duration": "Number",
  "location": "String",
  "type": "String",
  "status": "String",
  "notes": "String",
  "feedback": "String",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```
### Student Details
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId",
  "studentId": "String",
  "firstName": "String",
  "lastName": "String",
  "dateOfBirth": "Date",
  "phoneNumber": "String",
  "address": "String",
  "university": "String",
  "major": "String",
  "graduationYear": "Number",
  "resume": "String",
  "profilePicture": "String",
  "skills": ["String"],
  "languages": [
    {
      "name": "String",
      "level": "String"
    }
  ],
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Favorites Collection (Interviews)
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId",
  "offerId": "ObjectId",
  "createdAt": "Date"
}
```

### Chats Collection
```json
{
  "_id": "ObjectId",
  "studentId": "ObjectId",
  "providerId": "ObjectId",
  "serviceId": "ObjectId",
  "applicationId": "ObjectId",
  "messages": [
    {
      "senderId": "ObjectId",
      "message": "String",
      "attachments": ["String"],
      "timestamp": "Date",
      "read": "Boolean"
    }
  ],
  "lastMessageAt": "Date",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```
### Notifications Collection
```json
{
  "_id": "ObjectId",
  "recipientId": "ObjectId",
  "senderId": "ObjectId",
  "message": "String",
  "type": "String",
  "relatedId": "ObjectId",
  "seen": "Boolean",
  "createdAt": "Date"
}
```
### Files Collection (GridFS)
```json
{
  "_id": "ObjectId",
  "uuid": "String",
  "filename": "String",
  "contentType": "String",
  "size": "Number",
  "uploadDate": "Date",
  "metadata": {
    "uploadedBy": "ObjectId",
    "description": "String",
    "tags": ["String"]
  },
  "chunks": ["ObjectId"]
}
 ```

### Audit Logs Collection
```json
{
  "_id": "ObjectId",
  "user_uuid": "String",
  "entityClass": "String",
  "service": "String",
  "item_uuid": "String",
  "actionType": "String",
  "details": "Object",
  "ipAddress": "String",
  "userAgent": "String",
  "timestamp": "Date"
}
 ```

## Entity Relationships
1. User to ServiceCategory : Many-to-Many
   
   - Users (providers) can have multiple service categories
   - Service categories can be assigned to multiple users
2. User to Service : One-to-Many
   
   - A user (provider) can post multiple services
   - Each service is posted by one user
3. User to Application : One-to-Many
   
   - A student can submit multiple applications
   - Each application is submitted by one student
4. Service to Application : One-to-Many
   
   - A service can receive multiple applications
   - Each application is for one service
5. User to Company : One-to-Many
   
   - A user (ENTREPRISE_INDUSTRIELLE) can own multiple companies
   - Each company is owned by one user
6. Company to Offer : One-to-Many
   
   - A company can post multiple offers
   - Each offer belongs to one company
7. Offer to Application : One-to-Many
   
   - An offer can receive multiple applications
   - Each application is for one offer
8. Application to Interview : One-to-Many
   
   - An application can lead to multiple interviews
   - Each interview is related to one application
9. User to StudentDetails : One-to-One
   
   - A student user has one student details profile
   - Each student details profile belongs to one user
10. User to Favorites : One-to-Many
    
    - A student can have multiple favorite offers
    - Each favorite entry belongs to one student
11. User to Chat : Many-to-Many
    
    - A student can have chats with multiple providers
    - A provider can have chats with multiple students
    - Each chat is between one student and one provider
12. User to Notification : One-to-Many
    
    - A user can receive multiple notifications
    - Each notification is for one recipient
13. User to File : One-to-Many
    
    - A user can upload multiple files
    - Each file is uploaded by one user